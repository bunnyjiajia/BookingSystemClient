import React from "react";

function BookingSuccessful() {
    return (
        <>
            <div className="successfulbox">
        <h1 className=" className="theader>
            You have booked  <br />
            "Room" !
        </h1>
       
    </div>
        </>

    ) ;



}

export default BookingSuccessful