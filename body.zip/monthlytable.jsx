import React from "react";

function MonthlyTable() {
    return (
        <>
        
        <div>
            
            <table align="center" class="monthlytb" >
                <tbody>
                    <tr >

                        <th className="weekdayth" >Sunday</th>
                        <th className="weekdayth" >Monday</th>
                        <th className="weekdayth" >Tuesday</th>
                        <th className="weekdayth" >Wednesday</th>
                        <th className="weekdayth" >Thursday</th>
                        <th className="weekdayth" >Friday</th>
                        <th className="weekdayth" >Saturday</th>
                        
                    </tr>

                    <tr>
                        <td className="weekdaytd"></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td className="weekdaytd"></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td className="weekdaytd"></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td className="weekdaytd"></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>

                    <tr>
                        <td className="weekdaytd"></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
            
        </div>
        </>
    ) ;
}

export default MonthlyTable