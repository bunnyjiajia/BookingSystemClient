import React from "react";

function WeeklytTable() {
    return (
        <>
        
        <div>
            
        <div>
        
        <select name="stare" id="stare" className="dropdownalign">
          <option value="CB2" align="center" className="dropdownalign">CB2</option>
          <option value="LX Building (10th floor)" align="center" className="dropdownalign">LX Building (10th floor)</option>
          <option value="LX Building (11th floor)" align="center"className="dropdownalign">LX Building (11th floor)</option>
          <option value="LX Building (12th floor)" align="center"className="dropdownalign">LX Building (12th floor)</option>
          <option value="SIT Building (1st floor)" align="center"className="dropdownalign">SIT Building (1st floor)</option>
          <option value="SIT Building (3rd floor)" align="center"className="dropdownalign">SIT Building (3rd floor)</option>
          <option value="SIT Building (4th floor)" align="center"className="dropdownalign">SIT Building (4th floor)</option>
      
        </select>
      
        <select name="stare" id="stare" className="dropdownalign2">
          <option value="CB2" align="center" className="dropdownalign">CB2</option>
          <option value="LX Building (10th floor)" align="center" className="dropdownalign">LX Building (10th floor)</option>
          <option value="LX Building (11th floor)" align="center"className="dropdownalign">LX Building (11th floor)</option>
          <option value="LX Building (12th floor)" align="center"className="dropdownalign">LX Building (12th floor)</option>
          <option value="SIT Building (1st floor)" align="center"className="dropdownalign">SIT Building (1st floor)</option>
          <option value="SIT Building (3rd floor)" align="center"className="dropdownalign">SIT Building (3rd floor)</option>
          <option value="SIT Building (4th floor)" align="center"className="dropdownalign">SIT Building (4th floor)</option>
      
        </select>
              </div>
    
    
        
            <table align="center" style={{ margin: "0 auto" }} className="weeklytable">
                <tbody>
                    <tr>
                        <th className="colcolor">Time</th>
                        <th className="colcolor">SUN <br />D/M</th>
                        <th className="colcolor">MON <br />D/M</th>
                        <th className="colcolor">TUE <br />D/M</th>
                        <th className="colcolor">WED <br />D/M</th>
                        <th className="colcolor">THU <br />D/M</th>
                        <th className="colcolor">FRI <br />D/M</th>
                        <th className="colcolor">SAT <br />D/M</th>
                    </tr>

                 
            <tr>
                <td class="rowcolor">8:00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor">8:30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >9:00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >9:30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >10:00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >10:30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >11.00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >11.30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
            
            <tr>
                <td class="rowcolor" >12.00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor">12.30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >13.00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor">13.30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >14.00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >14.30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >15:00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >15:30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >16:00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >16:30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >17:00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >17:30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >18:00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >18:30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >19:00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >19:30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor">20:00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >20:30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >21:00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >21:30</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>

            <tr>
                <td class="rowcolor" >22:00</td>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
                </tbody>
            </table>
        </div>
        
        </>
    ) ;
}

export default WeeklytTable